saldo = 500
print(saldo)

saldo = 200
print(saldo)

saldo += 10
print(saldo)

saldo -= 5
print(saldo)

saldo //= 2
print(saldo)

saldo /= 2
print(saldo)

saldo *= 10
print(saldo)

saldo %= 4
print(saldo)

saldo **= 2
print(saldo)
