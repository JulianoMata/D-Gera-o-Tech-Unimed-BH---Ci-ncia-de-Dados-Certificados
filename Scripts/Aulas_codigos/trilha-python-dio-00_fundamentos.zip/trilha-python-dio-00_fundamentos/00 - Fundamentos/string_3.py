nome = "Guilherme Arthur de Carvalho"

print(nome[0])
print(nome[-2])
print(nome[:9])
print(nome[10:])
print(nome[10:16])
print(nome[10:16:2])
print(nome[:])
print(nome[::-1])
