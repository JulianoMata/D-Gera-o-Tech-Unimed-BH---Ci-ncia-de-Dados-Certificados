print("Oi, seja bem vindo ao curso de Python!")
